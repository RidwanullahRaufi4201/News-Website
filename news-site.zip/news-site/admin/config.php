<?php
$hostname = "http://localhost/news-site";

$conn = mysqli_connect("localhost","root","","newsdb") or die("Connection failed : " . mysqli_connect_error());

?>
